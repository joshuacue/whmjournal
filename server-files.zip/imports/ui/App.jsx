import React from 'react';

const App = () => (
  <div>
    <h1>Welcome to Meteor!</h1>
  </div>
);

export default App;
