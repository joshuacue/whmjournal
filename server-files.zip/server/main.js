import { Meteor } from 'meteor/meteor';
import { Mongo } from 'meteor/mongo';
export const Records = new Mongo.Collection('records');
export const AreaClearRecords = new Mongo.Collection('areaClearRecords');

Meteor.startup(() => {
  const server = 'https://c4bc4798.ngrok.io';
  const io = require('socket.io')();
  io.on('connection', Meteor.bindEnvironment((client) => {
    console.log('connected');
    client.on('disconnect', client => {
      console.log('disconnected');
    });
    client.on('record', Meteor.bindEnvironment((data) => {
      Records.insert(JSON.parse(data));
    }));
    client.on('areaClear', Meteor.bindEnvironment((data) => {
      AreaClearRecords.insert(JSON.parse(data));
    }));
    client.on('updateBirdList', Meteor.bindEnvironment((data) => {
      //TODO compare data to new data
      //TODO send new pictures
      let list = JSON.stringify([{
        image: `${server}/Birds/blackheadedgull.jpg`,
        text: 'BLACK HEADED GULL',
      },
      {
        image: `${server}/Birds/carrioncrow.png`,
        text: 'CARRION CROW',
      },
      {
        image: `${server}/Birds/commoncurlew.jpg`,
        text: 'COMMON CURLEW',
      },
      {
        image: `${server}/Birds/commongull.jpg`,
        text: 'COMMON GULL',
      },
      {
        image: `${server}/Birds/gheron.jpg`,
        text: 'GHERON',
      },
      {
        image: `${server}/Birds/herringgull.jpg`,
        text: 'HERRING GULL',
      },
      {
        image: `${server}/Birds/jackdaw.png`,
        text: 'JACKDAW',
      },
      {
        image: `${server}/Birds/lapwing.png`,
        text: 'LAPWING',
      },
      {
        image: `${server}/Birds/redwing.jpg`,
        text: 'REDWING',
      },
      {
        image: `${server}/Birds/rook.png`,
        text: 'ROOK',
      },
      {
        image: `${server}/Birds/skylark.png`,
        text: 'SKYLARK',
      },
      {
        image: `${server}/Birds/starling.png`,
        text: 'STARLING',
      },
      {
        image: `${server}/Birds/stockdove.jpg`,
        text: 'STOCKDOVE',
      },
      {
        image: `${server}/Birds/swallow.jpg`,
        text: 'SWALLOW',
      },
      {
        image: `${server}/Birds/wheatear.jpg`,
        text: 'WHEATEAR',
      },
      {
        image: `${server}/Birds/woodpigeon.png`,
        text: 'WOOD PIGEON',
      },
    ]);
      client.emit('updateBirdListReply', list);
    return list;
    }));
  }));
  io.listen(4000);
});