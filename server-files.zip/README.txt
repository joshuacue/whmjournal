Install NGROK.
Open NGROK and type, "ngrok http 3000".
Then run "meteor npm install" on directory of server-files
Then run "meteor"
Then edit server constant on server/main.js and put https link from ngrok