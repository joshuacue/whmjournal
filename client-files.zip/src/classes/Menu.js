export default class Menu {
  static get NAME() {
    return 'Menu';
  }
}
