export default class Login {
  static get NAME() {
    return 'Login';
  }
}
