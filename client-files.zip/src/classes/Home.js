export default class Home {
  static get NAME() {
    return 'Home';
  }
}
